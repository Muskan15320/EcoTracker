import React, { useState } from 'react';
import Dashboard from './components/Dashboard';
import TrackingForm from './components/TrackingForm';
import Goals from './components/Goals';
import Community from './components/Community';
import Learn from './components/Learn';
import Navigation from './components/Navigation';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderActiveComponent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'track':
        return <TrackingForm />;
      case 'goals':
        return <Goals />;
      case 'community':
        return <Community />;
      case 'learn':
        return <Learn />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex flex-col">
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
      <main className="container mx-auto px-4 py-6 flex-1">
        {renderActiveComponent()}
      </main>
    </div>
  );
}

export default App;