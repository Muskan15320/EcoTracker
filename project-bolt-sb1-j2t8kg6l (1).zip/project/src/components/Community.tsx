import React, { useState } from 'react';
import { Users, MessageCircle, Heart, Award, TrendingUp, Globe } from 'lucide-react';

const Community: React.FC = () => {
  const [activeTab, setActiveTab] = useState('leaderboard');

  const leaderboardData = [
    { rank: 1, name: 'EcoWarrior2025', points: 2847, reduction: '45%', avatar: '🌟' },
    { rank: 2, name: 'GreenMachine', points: 2634, reduction: '42%', avatar: '🌱' },
    { rank: 3, name: 'SustainableSam', points: 2401, reduction: '38%', avatar: '♻️' },
    { rank: 4, name: 'ClimateChamp', points: 2156, reduction: '35%', avatar: '🌍' },
    { rank: 5, name: 'You', points: 1847, reduction: '28%', avatar: '👤', isUser: true },
  ];

  const challenges = [
    {
      id: 1,
      title: 'Car-Free Week',
      description: 'Use alternative transportation for 7 days',
      participants: 1234,
      endDate: '2025-06-22',
      reward: '500 points',
      difficulty: 'Medium',
      joined: false
    },
    {
      id: 2,
      title: 'Zero Plastic Challenge',
      description: 'Avoid single-use plastics for 30 days',
      participants: 856,
      endDate: '2025-06-28',
      reward: '750 points',
      difficulty: 'Hard',
      joined: true
    },
    {
      id: 3,
      title: 'Local Food Month',
      description: 'Eat only locally sourced food',
      participants: 642,
      endDate: '2025-06-25',
      reward: '400 points',
      difficulty: 'Easy',
      joined: false
    }
  ];

  const posts = [
    {
      id: 1,
      author: 'EcoWarrior2025',
      avatar: '🌟',
      time: '2 hours ago',
      content: 'Just completed my first car-free week! Used my bike and public transport exclusively. Saved 15kg CO₂ and discovered some amazing bike paths in my city! 🚴‍♀️',
      likes: 24,
      comments: 8,
      image: true
    },
    {
      id: 2,
      author: 'GreenMachine',
      avatar: '🌱',
      time: '5 hours ago',
      content: 'Pro tip: Batch cooking on Sundays has reduced my food waste by 60%! Plus I save time during the week. Here\'s my meal prep strategy...',
      likes: 18,
      comments: 12,
      image: false
    },
    {
      id: 3,
      author: 'SustainableSam',
      avatar: '♻️',
      time: '1 day ago',
      content: 'Installed solar panels last month and my energy footprint is now negative! The installation process was easier than expected. Happy to answer questions!',
      likes: 42,
      comments: 15,
      image: true
    }
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">EcoTracker Community</h2>
        <p className="text-gray-600">Connect with fellow eco-warriors and share your journey</p>
      </div>

      {/* Community Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-sm p-6 text-center">
          <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-3">
            <Users className="w-6 h-6 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900">724</div>
          <div className="text-sm text-gray-600">Active Members</div>
        </div>
        <div className="bg-white rounded-xl shadow-sm p-6 text-center">
          <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-3">
            <Globe className="w-6 h-6 text-green-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900">2,456</div>
          <div className="text-sm text-gray-600">Tons CO₂ Saved</div>
        </div>
        <div className="bg-white rounded-xl shadow-sm p-6 text-center">
          <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-3">
            <Award className="w-6 h-6 text-purple-600" />
          </div>
          <div className="text-2xl font-bold text-gray-900">47</div>
          <div className="text-sm text-gray-600">Active Challenges</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg mb-6">
        {[
          { id: 'leaderboard', label: 'Leaderboard', icon: TrendingUp },
          { id: 'challenges', label: 'Challenges', icon: Award },
          { id: 'feed', label: 'Community Feed', icon: MessageCircle }
        ].map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 flex items-center justify-center space-x-2 py-2 px-4 rounded-md transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-white text-green-700 shadow-sm font-medium'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      {activeTab === 'leaderboard' && (
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-xl font-semibold text-gray-900 mb-6">Top Eco Champions</h3>
          <div className="space-y-4">
            {leaderboardData.map((user) => (
              <div
                key={user.rank}
                className={`flex items-center space-x-4 p-4 rounded-lg ${
                  user.isUser ? 'bg-green-50 border-2 border-green-200' : 'hover:bg-gray-50'
                } transition-colors duration-150`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                  user.rank === 1 ? 'bg-yellow-100 text-yellow-700' :
                  user.rank === 2 ? 'bg-gray-100 text-gray-700' :
                  user.rank === 3 ? 'bg-orange-100 text-orange-700' :
                  'bg-blue-100 text-blue-700'
                }`}>
                  {user.rank}
                </div>
                <div className="text-2xl">{user.avatar}</div>
                <div className="flex-1">
                  <div className={`font-semibold ${user.isUser ? 'text-green-700' : 'text-gray-900'}`}>
                    {user.name}
                  </div>
                  <div className="text-sm text-gray-600">
                    {user.points} points • {user.reduction} reduction
                  </div>
                </div>
                {user.isUser && (
                  <div className="text-sm font-medium text-green-600">You!</div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'challenges' && (
        <div className="space-y-6">
          {challenges.map((challenge) => (
            <div key={challenge.id} className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <h3 className="text-lg font-semibold text-gray-900">{challenge.title}</h3>
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      challenge.difficulty === 'Easy' ? 'bg-green-100 text-green-700' :
                      challenge.difficulty === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-red-100 text-red-700'
                    }`}>
                      {challenge.difficulty}
                    </span>
                  </div>
                  <p className="text-gray-600 mb-3">{challenge.description}</p>
                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <span>{challenge.participants} participants</span>
                    <span>Ends {new Date(challenge.endDate).toLocaleDateString()}</span>
                    <span className="font-medium text-green-600">{challenge.reward}</span>
                  </div>
                </div>
                <button
                  className={`px-4 py-2 rounded-lg font-medium transition-colors duration-200 ${
                    challenge.joined
                      ? 'bg-green-100 text-green-700 cursor-default'
                      : 'bg-green-600 text-white hover:bg-green-700'
                  }`}
                  disabled={challenge.joined}
                >
                  {challenge.joined ? 'Joined' : 'Join Challenge'}
                </button>
              </div>
              
              {challenge.joined && (
                <div className="mt-4 p-3 bg-green-50 rounded-lg">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-green-700">Your Progress</span>
                    <span className="font-medium text-green-700">3/7 days</span>
                  </div>
                  <div className="mt-2 w-full bg-green-200 rounded-full h-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{ width: '43%' }}></div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {activeTab === 'feed' && (
        <div className="space-y-6">
          {posts.map((post) => (
            <div key={post.id} className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center space-x-3 mb-4">
                <div className="text-2xl">{post.avatar}</div>
                <div>
                  <div className="font-semibold text-gray-900">{post.author}</div>
                  <div className="text-sm text-gray-500">{post.time}</div>
                </div>
              </div>
              
              <p className="text-gray-700 mb-4 leading-relaxed">{post.content}</p>
              
              {post.image && (
                <div className="w-full h-48 bg-gradient-to-r from-green-100 to-blue-100 rounded-lg mb-4 flex items-center justify-center">
                  <span className="text-gray-500">📸 Image placeholder</span>
                </div>
              )}
              
              <div className="flex items-center space-x-6 pt-4 border-t border-gray-100">
                <button className="flex items-center space-x-2 text-gray-500 hover:text-red-500 transition-colors duration-200">
                  <Heart className="w-4 h-4" />
                  <span>{post.likes}</span>
                </button>
                <button className="flex items-center space-x-2 text-gray-500 hover:text-blue-500 transition-colors duration-200">
                  <MessageCircle className="w-4 h-4" />
                  <span>{post.comments}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Community;