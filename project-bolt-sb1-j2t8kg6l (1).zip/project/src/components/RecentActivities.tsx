import React from 'react';
import { Clock, Car, Zap, Utensils, ShoppingBag } from 'lucide-react';

const RecentActivities: React.FC = () => {
  const activities = [
    {
      id: 1,
      type: 'transport',
      description: 'Bus commute to work',
      impact: '+0.12 kg CO₂',
      time: '2 hours ago',
      icon: Car,
      color: 'bg-blue-100 text-blue-600'
    },
    {
      id: 2,
      type: 'energy',
      description: 'Reduced AC usage',
      impact: '-0.8 kg CO₂',
      time: '4 hours ago',
      icon: Zap,
      color: 'bg-yellow-100 text-yellow-600'
    },
    {
      id: 3,
      type: 'food',
      description: 'Plant-based lunch',
      impact: '-0.5 kg CO₂',
      time: '6 hours ago',
      icon: Utensils,
      color: 'bg-green-100 text-green-600'
    },
    {
      id: 4,
      type: 'shopping',
      description: 'Bought eco-friendly products',
      impact: '-0.3 kg CO₂',
      time: '1 day ago',
      icon: ShoppingBag,
      color: 'bg-purple-100 text-purple-600'
    }
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <h3 className="text-xl font-semibold text-gray-900 mb-4">Recent Activities</h3>
      <div className="space-y-4">
        {activities.map((activity) => {
          const Icon = activity.icon;
          return (
            <div key={activity.id} className="flex items-center space-x-4 p-3 hover:bg-gray-50 rounded-lg transition-colors duration-150">
              <div className={`w-10 h-10 ${activity.color} rounded-lg flex items-center justify-center`}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="font-medium text-gray-900">{activity.description}</div>
                <div className="flex items-center space-x-2 text-sm text-gray-500">
                  <Clock className="w-3 h-3" />
                  <span>{activity.time}</span>
                </div>
              </div>
              <div className={`text-sm font-semibold ${
                activity.impact.startsWith('-') ? 'text-green-600' : 'text-red-600'
              }`}>
                {activity.impact}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default RecentActivities;