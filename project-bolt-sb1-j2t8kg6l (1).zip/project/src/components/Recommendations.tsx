import React from 'react';
import { Lightbulb, ArrowRight, Leaf, Recycle as Bicycle, Home } from 'lucide-react';

const Recommendations: React.FC = () => {
  const recommendations = [
    {
      id: 1,
      title: 'Switch to bike commuting',
      description: 'Replace 2 car trips per week with cycling',
      impact: 'Save 4.2 kg CO₂/week',
      difficulty: 'Easy',
      icon: Bicycle,
      color: 'bg-blue-500'
    },
    {
      id: 2,
      title: 'LED light upgrade',
      description: 'Replace remaining incandescent bulbs',
      impact: 'Save 1.8 kg CO₂/month',
      difficulty: 'Easy',
      icon: Home,
      color: 'bg-yellow-500'
    },
    {
      id: 3,
      title: 'Meatless Monday+',
      description: 'Add one more plant-based day per week',
      impact: 'Save 3.5 kg CO₂/week',
      difficulty: 'Medium',
      icon: Leaf,
      color: 'bg-green-500'
    }
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <div className="flex items-center space-x-2 mb-4">
        <Lightbulb className="w-5 h-5 text-amber-500" />
        <h3 className="text-xl font-semibold text-gray-900">AI Recommendations</h3>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {recommendations.map((rec) => {
          const Icon = rec.icon;
          return (
            <div key={rec.id} className="border border-gray-200 rounded-lg p-4 hover:border-green-300 transition-colors duration-200 cursor-pointer group">
              <div className="flex items-center space-x-3 mb-3">
                <div className={`w-10 h-10 ${rec.color} rounded-lg flex items-center justify-center`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-900">{rec.title}</h4>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    rec.difficulty === 'Easy' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                  }`}>
                    {rec.difficulty}
                  </span>
                </div>
              </div>
              
              <p className="text-sm text-gray-600 mb-3">{rec.description}</p>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-green-600">{rec.impact}</span>
                <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-green-500 transition-colors duration-200" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Recommendations;