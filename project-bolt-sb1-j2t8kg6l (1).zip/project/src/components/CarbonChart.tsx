import React from 'react';

const CarbonChart: React.FC = () => {
  const data = [
    { month: 'Jan', value: 3.2 },
    { month: 'Feb', value: 2.9 },
    { month: 'Mar', value: 3.1 },
    { month: 'Apr', value: 2.7 },
    { month: 'May', value: 2.4 },
    { month: 'Jun', value: 2.1 },
  ];

  const maxValue = Math.max(...data.map(d => d.value));

  return (
    <div className="space-y-4">
      <div className="flex items-end justify-between h-64 px-4">
        {data.map((item) => (
          <div key={item.month} className="flex flex-col items-center space-y-2 flex-1">
            <div className="relative w-full max-w-12 h-48 bg-gray-100 rounded-lg overflow-hidden">
              <div
                className="absolute bottom-0 w-full bg-gradient-to-t from-green-500 to-emerald-400 rounded-lg transition-all duration-700 ease-out"
                style={{ height: `${(item.value / maxValue) * 100}%` }}
              />
            </div>
            <div className="text-sm font-medium text-gray-700">{item.month}</div>
            <div className="text-xs text-gray-500">{item.value}t</div>
          </div>
        ))}
      </div>
      
      <div className="flex items-center justify-center space-x-4 text-sm text-gray-600">
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-gradient-to-r from-green-500 to-emerald-400 rounded-full"></div>
          <span>Monthly CO₂ Emissions (tons)</span>
        </div>
      </div>
    </div>
  );
};

export default CarbonChart;