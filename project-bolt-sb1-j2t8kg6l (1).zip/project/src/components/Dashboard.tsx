import React from 'react';
import { TrendingDown, TrendingUp, Award, Target, Zap, Car, ShoppingBag, Utensils } from 'lucide-react';
import StatCard from './StatCard';
import CarbonChart from './CarbonChart';
import RecentActivities from './RecentActivities';
import Recommendations from './Recommendations';

const Dashboard: React.FC = () => {
  const currentFootprint = 2.1; // tons CO2/month
  const previousFootprint = 2.8;
  const monthlyGoal = 1.8;
  const improvement = ((previousFootprint - currentFootprint) / previousFootprint * 100).toFixed(1);

  const categoryData = [
    { category: 'Transport', amount: 0.8, icon: Car, color: 'bg-blue-500' },
    { category: 'Energy', amount: 0.6, icon: Zap, color: 'bg-yellow-500' },
    { category: 'Food', amount: 0.4, icon: Utensils, color: 'bg-green-500' },
    { category: 'Shopping', amount: 0.3, icon: ShoppingBag, color: 'bg-purple-500' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Your Eco Dashboard</h2>
        <p className="text-gray-600">Track your progress towards a sustainable lifestyle</p>
      </div>

      {/* Main Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Current Footprint"
          value={`${currentFootprint} tons`}
          subtitle="CO₂ this month"
          icon={TrendingDown}
          iconColor="text-green-600"
          trend={`${improvement}% reduction`}
          trendUp={false}
        />
        <StatCard
          title="Monthly Goal"
          value={`${monthlyGoal} tons`}
          subtitle="Target CO₂"
          icon={Target}
          iconColor="text-blue-600"
          trend={`${((currentFootprint - monthlyGoal) * 100 / monthlyGoal).toFixed(1)}% above goal`}
          trendUp={true}
        />
        <StatCard
          title="Eco Score"
          value="847"
          subtitle="This month"
          icon={Award}
          iconColor="text-amber-600"
          trend="+124 points"
          trendUp={false}
        />
        <StatCard
          title="Days Streak"
          value="12"
          subtitle="Consecutive tracking"
          icon={TrendingUp}
          iconColor="text-purple-600"
          trend="New record!"
          trendUp={false}
        />
      </div>

      {/* Carbon Footprint Chart */}
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-4">Carbon Footprint Trend</h3>
        <CarbonChart />
      </div>

      {/* Category Breakdown & Recent Activities */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">Category Breakdown</h3>
          <div className="space-y-4">
            {categoryData.map((item) => {
              const Icon = item.icon;
              return (
                <div key={item.category} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 ${item.color} rounded-lg flex items-center justify-center`}>
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                    <span className="font-medium text-gray-900">{item.category}</span>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-gray-900">{item.amount} tons</div>
                    <div className="text-sm text-gray-500">CO₂</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <RecentActivities />
      </div>

      {/* AI Recommendations */}
      <Recommendations />
    </div>
  );
};

export default Dashboard;