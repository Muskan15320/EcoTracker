import React, { useState } from 'react';
import { Car, Zap, Utensils, ShoppingBag, Plus, CheckCircle } from 'lucide-react';

const TrackingForm: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('transport');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const categories = [
    { id: 'transport', label: 'Transport', icon: Car, color: 'bg-blue-500' },
    { id: 'energy', label: 'Energy', icon: Zap, color: 'bg-yellow-500' },
    { id: 'food', label: 'Food', icon: Utensils, color: 'bg-green-500' },
    { id: 'shopping', label: 'Shopping', icon: ShoppingBag, color: 'bg-purple-500' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setIsSubmitting(false);
    setShowSuccess(true);
    
    setTimeout(() => setShowSuccess(false), 3000);
  };

  const renderTransportForm = () => (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Transport Mode</label>
        <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
          <option>Car (Gasoline)</option>
          <option>Car (Electric)</option>
          <option>Bus</option>
          <option>Train</option>
          <option>Bicycle</option>
          <option>Walking</option>
          <option>Motorcycle</option>
          <option>Flight</option>
        </select>
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Distance (km)</label>
        <input 
          type="number" 
          placeholder="Enter distance"
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Purpose</label>
        <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
          <option>Commute</option>
          <option>Leisure</option>
          <option>Business</option>
          <option>Shopping</option>
          <option>Other</option>
        </select>
      </div>
    </div>
  );

  const renderEnergyForm = () => (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Energy Type</label>
        <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent">
          <option>Electricity</option>
          <option>Natural Gas</option>
          <option>Heating Oil</option>
          <option>Solar</option>
          <option>Wind</option>
        </select>
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Usage (kWh)</label>
        <input 
          type="number" 
          placeholder="Enter energy usage"
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Period</label>
        <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent">
          <option>Daily</option>
          <option>Weekly</option>
          <option>Monthly</option>
        </select>
      </div>
    </div>
  );

  const renderFoodForm = () => (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Meal Type</label>
        <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent">
          <option>Breakfast</option>
          <option>Lunch</option>
          <option>Dinner</option>
          <option>Snack</option>
        </select>
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Diet Category</label>
        <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent">
          <option>Meat-heavy</option>
          <option>Balanced</option>
          <option>Vegetarian</option>
          <option>Vegan</option>
          <option>Seafood</option>
        </select>
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Local/Organic</label>
        <div className="flex space-x-4">
          <label className="flex items-center">
            <input type="checkbox" className="rounded border-gray-300 text-green-600 focus:ring-green-500" />
            <span className="ml-2 text-sm text-gray-700">Local produce</span>
          </label>
          <label className="flex items-center">
            <input type="checkbox" className="rounded border-gray-300 text-green-600 focus:ring-green-500" />
            <span className="ml-2 text-sm text-gray-700">Organic</span>
          </label>
        </div>
      </div>
    </div>
  );

  const renderShoppingForm = () => (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Product Category</label>
        <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
          <option>Electronics</option>
          <option>Clothing</option>
          <option>Home & Garden</option>
          <option>Books & Media</option>
          <option>Cosmetics</option>
          <option>Other</option>
        </select>
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Amount Spent ($)</label>
        <input 
          type="number" 
          placeholder="Enter amount"
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Sustainability</label>
        <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
          <option>New/Regular</option>
          <option>Second-hand</option>
          <option>Eco-friendly</option>
          <option>Refurbished</option>
        </select>
      </div>
    </div>
  );

  const renderForm = () => {
    switch (selectedCategory) {
      case 'transport':
        return renderTransportForm();
      case 'energy':
        return renderEnergyForm();
      case 'food':
        return renderFoodForm();
      case 'shopping':
        return renderShoppingForm();
      default:
        return renderTransportForm();
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Track Your Impact</h2>
        <p className="text-gray-600">Log your daily activities to calculate your carbon footprint</p>
      </div>

      {/* Category Selection */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {categories.map((category) => {
          const Icon = category.icon;
          return (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`p-4 rounded-xl border-2 transition-all duration-200 ${
                selectedCategory === category.id
                  ? 'border-current bg-opacity-10'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              style={{
                borderColor: selectedCategory === category.id ? category.color.replace('bg-', '').replace('-500', '') : undefined,
                backgroundColor: selectedCategory === category.id ? category.color.replace('bg-', '').replace('-500', '') + '1A' : undefined
              }}
            >
              <div className={`w-12 h-12 ${category.color} rounded-lg flex items-center justify-center mx-auto mb-2`}>
                <Icon className="w-6 h-6 text-white" />
              </div>
              <div className="font-medium text-gray-900">{category.label}</div>
            </button>
          );
        })}
      </div>

      {/* Form */}
      <div className="bg-white rounded-xl shadow-sm p-6">
        <form onSubmit={handleSubmit}>
          {renderForm()}
          
          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-600">
                Estimated CO₂ impact: <span className="font-semibold text-gray-900">+0.75 kg</span>
              </div>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors duration-200 flex items-center space-x-2 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Saving...</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4" />
                    <span>Track Activity</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* Success Message */}
      {showSuccess && (
        <div className="fixed bottom-4 right-4 bg-green-600 text-white px-6 py-3 rounded-lg shadow-lg flex items-center space-x-2 animate-slide-up">
          <CheckCircle className="w-5 h-5" />
          <span>Activity tracked successfully!</span>
        </div>
      )}
    </div>
  );
};

export default TrackingForm;