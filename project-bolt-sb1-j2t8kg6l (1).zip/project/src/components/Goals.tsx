import React, { useState } from 'react';
import { Target, Trophy, Calendar, TrendingDown, Plus, Edit2 } from 'lucide-react';

const Goals: React.FC = () => {
  const [showNewGoalModal, setShowNewGoalModal] = useState(false);

  const currentGoals = [
    {
      id: 1,
      title: 'Reduce Monthly Footprint',
      target: 1.8,
      current: 2.1,
      unit: 'tons CO₂',
      deadline: '2025-06-28',
      progress: 72,
      category: 'overall'
    },
    {
      id: 2,
      title: 'Bike to Work',
      target: 8,
      current: 5,
      unit: 'days/month',
      deadline: '2025-06-25',
      progress: 63,
      category: 'transport'
    },
    {
      id: 3,
      title: 'Plant-based Meals',
      target: 15,
      current: 12,
      unit: 'meals/month',
      deadline: '2025-06-22',
      progress: 80,
      category: 'food'
    }
  ];

  const achievements = [
    {
      id: 1,
      title: 'First Week Streak',
      description: 'Tracked activities for 7 consecutive days',
      icon: '🏆',
      earned: '2025-06-15',
      points: 100
    },
    {
      id: 2,
      title: 'Transport Hero',
      description: 'Used public transport 20 times',
      icon: '🚌',
      earned: '2025-06-18',
      points: 150
    },
    {
      id: 3,
      title: 'Green Eater',
      description: 'Had 30 plant-based meals',
      icon: '🌱',
      earned: '2025-06-20',
      points: 200
    }
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Your Eco Goals</h2>
        <p className="text-gray-600">Set targets and track your progress towards sustainability</p>
      </div>

      {/* Current Goals */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-semibold text-gray-900">Current Goals</h3>
          <button
            onClick={() => setShowNewGoalModal(true)}
            className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200 flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>New Goal</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {currentGoals.map((goal) => (
            <div key={goal.id} className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow duration-200">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-semibold text-gray-900">{goal.title}</h4>
                <button className="text-gray-400 hover:text-gray-600">
                  <Edit2 className="w-4 h-4" />
                </button>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Progress</span>
                  <span className="font-medium text-gray-900">{goal.progress}%</span>
                </div>
                
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-green-500 to-emerald-400 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${goal.progress}%` }}
                  ></div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-lg font-bold text-gray-900">{goal.current}</div>
                    <div className="text-xs text-gray-500">Current</div>
                  </div>
                  <TrendingDown className="w-5 h-5 text-green-600" />
                  <div className="text-right">
                    <div className="text-lg font-bold text-green-600">{goal.target}</div>
                    <div className="text-xs text-gray-500">Target</div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 text-sm text-gray-500">
                  <Calendar className="w-4 h-4" />
                  <span>Due: {new Date(goal.deadline).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Achievements */}
      <div>
        <h3 className="text-xl font-semibold text-gray-900 mb-6">Achievements</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {achievements.map((achievement) => (
            <div key={achievement.id} className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-amber-400">
              <div className="flex items-center space-x-4">
                <div className="text-3xl">{achievement.icon}</div>
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-900 mb-1">{achievement.title}</h4>
                  <p className="text-sm text-gray-600 mb-2">{achievement.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500">
                      Earned: {new Date(achievement.earned).toLocaleDateString()}
                    </span>
                    <span className="text-sm font-medium text-amber-600">
                      +{achievement.points} pts
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Upcoming Challenges */}
      <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Trophy className="w-5 h-5 text-green-600" />
          <h3 className="text-xl font-semibold text-gray-900">Weekly Challenge</h3>
        </div>
        <div className="md:flex md:items-center md:justify-between">
          <div>
            <h4 className="font-semibold text-gray-900 mb-2">Zero Waste Week</h4>
            <p className="text-gray-600 mb-4 md:mb-0">
              Reduce your waste to zero for one week. Track all items you dispose of and find alternatives.
            </p>
          </div>
          <button className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200">
            Join Challenge
          </button>
        </div>
      </div>

      {/* New Goal Modal */}
      {showNewGoalModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Set New Goal</h3>
              <button
                onClick={() => setShowNewGoalModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                ×
              </button>
            </div>
            
            <form className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Goal Title</label>
                <input
                  type="text"
                  placeholder="Enter goal title"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent">
                  <option>Overall Footprint</option>
                  <option>Transport</option>
                  <option>Energy</option>
                  <option>Food</option>
                  <option>Shopping</option>
                </select>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Target Value</label>
                  <input
                    type="number"
                    placeholder="0"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Unit</label>
                  <input
                    type="text"
                    placeholder="kg CO₂"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Deadline</label>
                <input
                  type="date"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              
              <div className="flex space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowNewGoalModal(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors duration-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
                >
                  Create Goal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Goals;