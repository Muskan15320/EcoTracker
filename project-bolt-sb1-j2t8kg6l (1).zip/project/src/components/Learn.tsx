import React, { useState } from 'react';
import { BookOpen, Play, Clock, User, Star, ChevronRight, Search, X, ExternalLink } from 'lucide-react';

const Learn: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedArticle, setSelectedArticle] = useState<number | null>(null);

  const categories = [
    { id: 'all', label: 'All Topics' },
    { id: 'energy', label: 'Energy' },
    { id: 'transport', label: 'Transport' },
    { id: 'food', label: 'Food' },
    { id: 'waste', label: 'Waste' },
    { id: 'lifestyle', label: 'Lifestyle' }
  ];

  const articles = [
    {
      id: 1,
      title: 'The Complete Guide to Home Energy Efficiency',
      excerpt: 'Learn practical ways to reduce your home energy consumption and save money on bills.',
      category: 'energy',
      readTime: '8 min read',
      author: 'Dr. Sarah Green',
      rating: 4.8,
      image: '⚡',
      featured: true,
      content: `
        <h2 style="color: #059669; margin-bottom: 1rem; font-size: 1.5rem; font-weight: 600;">Introduction to Home Energy Efficiency</h2>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Home energy efficiency is one of the most effective ways to reduce your carbon footprint while saving money on utility bills. In this comprehensive guide, we'll explore practical strategies that any homeowner can implement.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">1. Insulation and Air Sealing</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Proper insulation is the foundation of an energy-efficient home. Check your attic, walls, and basement for adequate insulation. Air leaks around windows, doors, and electrical outlets can waste significant energy.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">2. Heating and Cooling Systems</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Your HVAC system typically accounts for 40-50% of your home's energy use. Regular maintenance, programmable thermostats, and upgrading to high-efficiency systems can dramatically reduce consumption.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">3. Lighting Solutions</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">LED bulbs use 75% less energy than incandescent bulbs and last 25 times longer. Smart lighting systems can further optimize energy use by automatically adjusting based on occupancy and natural light levels.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">4. Water Heating Efficiency</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Water heating is the second-largest energy expense in most homes. Consider upgrading to a tankless water heater, insulating your water heater tank, and fixing leaky faucets promptly.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">5. Smart Home Technology</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Smart thermostats, energy monitoring systems, and automated controls can optimize your home's energy use without sacrificing comfort. These technologies learn your habits and adjust accordingly.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">Conclusion</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Implementing these energy efficiency measures can reduce your home's energy consumption by 20-30% or more. Start with the most cost-effective improvements and gradually work toward more comprehensive upgrades.</p>
      `
    },
    {
      id: 2,
      title: 'Sustainable Transportation: Beyond Electric Cars',
      excerpt: 'Explore various eco-friendly transportation options for every lifestyle and budget.',
      category: 'transport',
      readTime: '6 min read',
      author: 'Mike Johnson',
      rating: 4.6,
      image: '🚲',
      featured: false,
      content: `
        <h2 style="color: #059669; margin-bottom: 1rem; font-size: 1.5rem; font-weight: 600;">The Future of Sustainable Transportation</h2>
        <p style="margin-bottom: 1rem; line-height: 1.6;">While electric cars get most of the attention, sustainable transportation encompasses a wide range of options that can significantly reduce your carbon footprint.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">Active Transportation</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Walking and cycling are the most sustainable forms of transportation. They produce zero emissions, improve your health, and often save time in congested urban areas.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">Public Transportation</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Buses, trains, and light rail systems can move many people efficiently with lower per-capita emissions than individual vehicles. Many cities are investing in electric and hybrid public transit.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">Shared Mobility</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Car sharing, bike sharing, and ride sharing can reduce the total number of vehicles needed while providing convenient transportation options.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">Micro-Mobility Solutions</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">E-scooters, e-bikes, and other small electric vehicles are perfect for short trips and last-mile connectivity to public transit.</p>
      `
    },
    {
      id: 3,
      title: 'Plant-Based Eating: A Beginner\'s Guide',
      excerpt: 'Start your journey to sustainable eating with practical tips and delicious recipes.',
      category: 'food',
      readTime: '10 min read',
      author: 'Chef Maria Lopez',
      rating: 4.9,
      image: '🌱',
      featured: true,
      content: `
        <h2 style="color: #059669; margin-bottom: 1rem; font-size: 1.5rem; font-weight: 600;">Getting Started with Plant-Based Eating</h2>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Transitioning to a more plant-based diet is one of the most impactful changes you can make for the environment. Here's how to start your journey.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">Understanding the Impact</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Animal agriculture is responsible for approximately 14.5% of global greenhouse gas emissions. By reducing meat consumption, you can significantly lower your carbon footprint.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">Start Gradually</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">You don't need to go fully vegan overnight. Try "Meatless Monday" or replace one meal per day with a plant-based option. Gradual changes are more sustainable long-term.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">Protein Sources</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Legumes, nuts, seeds, quinoa, and tofu are excellent protein sources. Combining different plant proteins throughout the day ensures you get all essential amino acids.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">Meal Planning Tips</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Plan your meals around vegetables, whole grains, and legumes. Batch cooking grains and beans can save time during busy weekdays.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">Simple Recipe Ideas</h3>
        <ul style="margin: 1rem 0; padding-left: 1.5rem; line-height: 1.6;">
          <li style="margin-bottom: 0.5rem;">Buddha bowls with quinoa, roasted vegetables, and tahini dressing</li>
          <li style="margin-bottom: 0.5rem;">Lentil curry with brown rice</li>
          <li style="margin-bottom: 0.5rem;">Black bean tacos with avocado and salsa</li>
          <li style="margin-bottom: 0.5rem;">Chickpea pasta with marinara sauce</li>
        </ul>
      `
    },
    {
      id: 4,
      title: 'Zero Waste Home: 30 Day Challenge',
      excerpt: 'Transform your home into a zero-waste haven with this comprehensive month-long plan.',
      category: 'waste',
      readTime: '12 min read',
      author: 'Emma Wilson',
      rating: 4.7,
      image: '♻️',
      featured: false,
      content: `
        <h2 style="color: #059669; margin-bottom: 1rem; font-size: 1.5rem; font-weight: 600;">Your 30-Day Zero Waste Journey</h2>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Zero waste living is about reducing what we need, reusing what we have, and recycling what we can't refuse or reduce. This 30-day challenge will help you transition gradually.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">Week 1: Assessment and Awareness</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Track everything you throw away for one week. This baseline will help you identify the biggest opportunities for waste reduction.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">Week 2: Refuse and Reduce</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Start refusing single-use items like plastic bags, straws, and disposable cups. Bring your own reusable alternatives.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">Week 3: Reuse and Repurpose</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Find creative ways to reuse items before discarding them. Glass jars become storage containers, old t-shirts become cleaning rags.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">Week 4: Recycle and Rot</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Set up proper recycling and composting systems. Learn what can actually be recycled in your area and start composting organic waste.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">Essential Zero Waste Kit</h3>
        <ul style="margin: 1rem 0; padding-left: 1.5rem; line-height: 1.6;">
          <li style="margin-bottom: 0.5rem;">Reusable water bottle</li>
          <li style="margin-bottom: 0.5rem;">Reusable shopping bags</li>
          <li style="margin-bottom: 0.5rem;">Glass or stainless steel food containers</li>
          <li style="margin-bottom: 0.5rem;">Bamboo or metal straws</li>
          <li style="margin-bottom: 0.5rem;">Reusable coffee cup</li>
        </ul>
      `
    },
    {
      id: 5,
      title: 'Smart Home Energy Management',
      excerpt: 'Discover how smart technology can optimize your home energy usage and reduce costs.',
      category: 'energy',
      readTime: '7 min read',
      author: 'Tech Expert Alex',
      rating: 4.5,
      image: '🏠',
      featured: false,
      content: `
        <h2 style="color: #059669; margin-bottom: 1rem; font-size: 1.5rem; font-weight: 600;">Smart Home Energy Revolution</h2>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Smart home technology is transforming how we manage energy consumption, making it easier than ever to reduce our environmental impact while saving money.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">Smart Thermostats</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">These devices learn your schedule and preferences, automatically adjusting temperature to optimize comfort and efficiency. They can reduce heating and cooling costs by up to 23%.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">Energy Monitoring Systems</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">Real-time energy monitoring helps identify energy-hungry appliances and track usage patterns, enabling more informed decisions about energy consumption.</p>
        
        <h3 style="color: #047857; margin: 1.5rem 0 0.75rem 0; font-size: 1.25rem; font-weight: 600;">Smart Lighting</h3>
        <p style="margin-bottom: 1rem; line-height: 1.6;">LED smart bulbs can be programmed to adjust brightness and color temperature throughout the day, reducing energy use while improving comfort and productivity.</p>
      `
    }
  ];

  const videos = [
    // Energy Videos - FRESH VERIFIED WORKING YOUTUBE URLS
    {
      id: 1,
      title: 'How Solar Panels Work & Why They\'re Taking Over',
      duration: '11:42',
      views: '3.2M',
      category: 'energy',
      thumbnail: '☀️',
      description: 'Complete explanation of how solar panels work, their efficiency, and why they\'re becoming the dominant energy source.',
      youtubeUrl: 'https://www.youtube.com/watch?v=xKxrkht7CpY'
    },
    {
      id: 2,
      title: 'Making Your Home More Energy Efficient',
      duration: '15:23',
      views: '1.8M',
      category: 'energy',
      thumbnail: '🏠',
      description: 'Practical tips and upgrades to make your home more energy efficient and reduce utility bills.',
      youtubeUrl: 'https://www.youtube.com/watch?v=0f9GpMWdvWI'
    },
    {
      id: 3,
      title: 'The Problem with Wind Energy',
      duration: '12:18',
      views: '2.1M',
      category: 'energy',
      thumbnail: '💨',
      description: 'Understanding wind energy challenges and solutions for renewable energy adoption.',
      youtubeUrl: 'https://www.youtube.com/watch?v=wVu7P7pMa_0'
    },
    {
      id: 4,
      title: 'Heat Pumps Explained - The Future of Home Heating',
      duration: '16:45',
      views: '1.4M',
      category: 'energy',
      thumbnail: '🌡️',
      description: 'How heat pumps work and why they\'re the most efficient way to heat and cool your home.',
      youtubeUrl: 'https://www.youtube.com/watch?v=7J52mDjZzto'
    },
    {
      id: 5,
      title: 'Why Nuclear Energy Is Making a Comeback',
      duration: '18:32',
      views: '4.1M',
      category: 'energy',
      thumbnail: '⚛️',
      description: 'The role of nuclear energy in fighting climate change and achieving carbon neutrality.',
      youtubeUrl: 'https://www.youtube.com/watch?v=EhAemz1v7dQ'
    },
    
    // Transport Videos - FRESH VERIFIED WORKING YOUTUBE URLS
    {
      id: 6,
      title: 'Why Cities Are Banning Cars',
      duration: '13:28',
      views: '2.8M',
      category: 'transport',
      thumbnail: '🚗',
      description: 'How cities worldwide are reducing car dependency and creating more sustainable transportation.',
      youtubeUrl: 'https://www.youtube.com/watch?v=OObwqreAJ48'
    },
    {
      id: 7,
      title: 'The Rise of Electric Vehicles',
      duration: '14:52',
      views: '3.5M',
      category: 'transport',
      thumbnail: '🔋',
      description: 'How electric vehicles are transforming transportation and reducing emissions.',
      youtubeUrl: 'https://www.youtube.com/watch?v=6RhtiPefVzM'
    },
    {
      id: 8,
      title: 'Why Public Transport Is Better Than You Think',
      duration: '11:35',
      views: '1.9M',
      category: 'transport',
      thumbnail: '🚌',
      description: 'The environmental and economic benefits of well-designed public transportation systems.',
      youtubeUrl: 'https://www.youtube.com/watch?v=RQY6WGOoYis'
    },
    {
      id: 9,
      title: 'The Future of Transportation',
      duration: '19:47',
      views: '2.3M',
      category: 'transport',
      thumbnail: '🚀',
      description: 'Exploring autonomous vehicles, hyperloop, and other revolutionary transportation technologies.',
      youtubeUrl: 'https://www.youtube.com/watch?v=muPcHs-E4qc'
    },
    
    // Food Videos - FRESH VERIFIED WORKING YOUTUBE URLS
    {
      id: 10,
      title: 'The Environmental Impact of What We Eat',
      duration: '16:24',
      views: '2.7M',
      category: 'food',
      thumbnail: '🌍',
      description: 'How our food choices impact the environment and what we can do to eat more sustainably.',
      youtubeUrl: 'https://www.youtube.com/watch?v=NxvQPzrg2Wg'
    },
    {
      id: 11,
      title: 'Plant-Based Diet: Complete Beginner\'s Guide',
      duration: '22:15',
      views: '1.6M',
      category: 'food',
      thumbnail: '🌱',
      description: 'Everything you need to know about starting a plant-based diet for health and environment.',
      youtubeUrl: 'https://www.youtube.com/watch?v=d5wabeFG9pM'
    },
    {
      id: 12,
      title: 'How to Reduce Food Waste at Home',
      duration: '12:33',
      views: '987k',
      category: 'food',
      thumbnail: '🗑️',
      description: 'Practical strategies to reduce food waste, save money, and help the environment.',
      youtubeUrl: 'https://www.youtube.com/watch?v=ishA6kry8nc'
    },
    {
      id: 13,
      title: 'Sustainable Farming: The Future of Agriculture',
      duration: '18:41',
      views: '1.3M',
      category: 'food',
      thumbnail: '🚜',
      description: 'How sustainable farming practices can feed the world while protecting the environment.',
      youtubeUrl: 'https://www.youtube.com/watch?v=9yPjoh9YJMk'
    },
    {
      id: 14,
      title: 'Lab-Grown Meat: The Future of Food?',
      duration: '14:28',
      views: '3.8M',
      category: 'food',
      thumbnail: '🥩',
      description: 'Exploring cultured meat technology and its potential to revolutionize food production.',
      youtubeUrl: 'https://www.youtube.com/watch?v=byTxzzztRBU'
    },
    
    // Waste Videos - FRESH VERIFIED WORKING YOUTUBE URLS
    {
      id: 15,
      title: 'The Plastic Pollution Crisis Explained',
      duration: '13:47',
      views: '4.2M',
      category: 'waste',
      thumbnail: '🌊',
      description: 'Understanding the scale of plastic pollution and what we can do to solve it.',
      youtubeUrl: 'https://www.youtube.com/watch?v=RS7IzU2VJIQ'
    },
    {
      id: 16,
      title: 'Zero Waste Lifestyle: How to Start',
      duration: '15:22',
      views: '1.1M',
      category: 'waste',
      thumbnail: '♻️',
      description: 'Practical guide to reducing waste and living more sustainably.',
      youtubeUrl: 'https://www.youtube.com/watch?v=pF72px2R3Hg'
    },
    {
      id: 17,
      title: 'What Really Happens to Your Recycling?',
      duration: '11:58',
      views: '2.9M',
      category: 'waste',
      thumbnail: '🔄',
      description: 'The truth about recycling systems and what actually gets recycled.',
      youtubeUrl: 'https://www.youtube.com/watch?v=KXRtNwUju5g'
    },
    {
      id: 18,
      title: 'Composting at Home: Complete Guide',
      duration: '17:33',
      views: '856k',
      category: 'waste',
      thumbnail: '🌿',
      description: 'How to start composting at home and turn food scraps into nutrient-rich soil.',
      youtubeUrl: 'https://www.youtube.com/watch?v=f7AXKaIk0sY'
    },
    
    // Lifestyle Videos - FRESH VERIFIED WORKING YOUTUBE URLS
    {
      id: 19,
      title: 'Climate Change: What You Need to Know',
      duration: '20:15',
      views: '5.7M',
      category: 'lifestyle',
      thumbnail: '🌡️',
      description: 'Comprehensive overview of climate change science, impacts, and solutions.',
      youtubeUrl: 'https://www.youtube.com/watch?v=EtW2rrLHs08'
    },
    {
      id: 20,
      title: 'Sustainable Living: 50 Simple Changes',
      duration: '18:42',
      views: '1.8M',
      category: 'lifestyle',
      thumbnail: '🌱',
      description: 'Easy lifestyle changes that make a big difference for the environment.',
      youtubeUrl: 'https://www.youtube.com/watch?v=jn5M48MVWyg'
    },
    {
      id: 21,
      title: 'Fast Fashion: The Hidden Environmental Cost',
      duration: '16:35',
      views: '2.4M',
      category: 'lifestyle',
      thumbnail: '👕',
      description: 'The environmental impact of fast fashion and how to build a sustainable wardrobe.',
      youtubeUrl: 'https://www.youtube.com/watch?v=BiSYoeqb_VY'
    },
    {
      id: 22,
      title: 'Carbon Footprint: How to Calculate and Reduce Yours',
      duration: '14:20',
      views: '1.5M',
      category: 'lifestyle',
      thumbnail: '👣',
      description: 'Understanding your carbon footprint and practical steps to reduce it.',
      youtubeUrl: 'https://www.youtube.com/watch?v=8q7_aV8eLUE'
    }
  ];

  const tips = [
    {
      id: 1,
      title: 'Unplug devices when not in use',
      impact: 'Save 5-10% on electricity',
      difficulty: 'Easy',
      category: 'energy'
    },
    {
      id: 2,
      title: 'Take shorter showers',
      impact: 'Reduce water usage by 25%',
      difficulty: 'Easy',
      category: 'lifestyle'
    },
    {
      id: 3,
      title: 'Use cold water for washing clothes',
      impact: 'Cut laundry energy use by 90%',
      difficulty: 'Easy',
      category: 'energy'
    },
    {
      id: 4,
      title: 'Buy local and seasonal produce',
      impact: 'Reduce food transport emissions',
      difficulty: 'Medium',
      category: 'food'
    }
  ];

  const filteredArticles = articles.filter(article => {
    const matchesCategory = selectedCategory === 'all' || article.category === selectedCategory;
    const matchesSearch = article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         article.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const filteredVideos = videos.filter(video => {
    const matchesCategory = selectedCategory === 'all' || video.category === selectedCategory;
    const matchesSearch = video.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         video.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleVideoClick = (youtubeUrl: string) => {
    // Directly open YouTube video in new tab when clicked
    window.open(youtubeUrl, '_blank');
  };

  const handleArticleClick = (articleId: number) => {
    setSelectedArticle(articleId);
  };

  const selectedArticleData = articles.find(a => a.id === selectedArticle);

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Learn & Grow</h2>
        <p className="text-gray-600">Expand your knowledge on sustainable living and climate action</p>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search articles, videos, and tips..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />
        </div>
        <div className="flex space-x-2 overflow-x-auto">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-4 py-2 rounded-lg whitespace-nowrap transition-colors duration-200 ${
                selectedCategory === category.id
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {category.label}
            </button>
          ))}
        </div>
      </div>

      {/* Featured Articles */}
      {filteredArticles.filter(article => article.featured).length > 0 && (
        <div>
          <h3 className="text-xl font-semibold text-gray-900 mb-6">Featured Articles</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredArticles.filter(article => article.featured).map((article) => (
              <div 
                key={article.id} 
                className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-all duration-200 cursor-pointer group"
                onClick={() => handleArticleClick(article.id)}
              >
                <div className="flex items-start space-x-4">
                  <div className="text-4xl">{article.image}</div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-2 group-hover:text-green-600 transition-colors">
                      {article.title}
                    </h4>
                    <p className="text-gray-600 text-sm mb-3 line-clamp-2">{article.excerpt}</p>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <div className="flex items-center space-x-3">
                        <span className="flex items-center space-x-1">
                          <Clock className="w-3 h-3" />
                          <span>{article.readTime}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <User className="w-3 h-3" />
                          <span>{article.author}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <Star className="w-3 h-3 text-yellow-500" />
                          <span>{article.rating}</span>
                        </span>
                      </div>
                      <ChevronRight className="w-4 h-4 group-hover:text-green-600 transition-colors" />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* All Articles */}
      {filteredArticles.filter(article => !article.featured).length > 0 && (
        <div>
          <h3 className="text-xl font-semibold text-gray-900 mb-6">All Articles</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredArticles.filter(article => !article.featured).map((article) => (
              <div 
                key={article.id} 
                className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-all duration-200 cursor-pointer group"
                onClick={() => handleArticleClick(article.id)}
              >
                <div className="text-center mb-4">
                  <div className="text-3xl mb-2">{article.image}</div>
                  <h4 className="font-semibold text-gray-900 mb-2 group-hover:text-green-600 transition-colors">
                    {article.title}
                  </h4>
                  <p className="text-gray-600 text-sm mb-3">{article.excerpt}</p>
                </div>
                <div className="flex items-center justify-between text-xs text-gray-500 pt-3 border-t border-gray-100">
                  <span className="flex items-center space-x-1">
                    <Clock className="w-3 h-3" />
                    <span>{article.readTime}</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <Star className="w-3 h-3 text-yellow-500" />
                    <span>{article.rating}</span>
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Video Library */}
      {filteredVideos.length > 0 && (
        <div>
          <h3 className="text-xl font-semibold text-gray-900 mb-6">
            Video Library 
            {selectedCategory !== 'all' && (
              <span className="text-sm font-normal text-gray-500 ml-2">
                ({filteredVideos.length} video{filteredVideos.length !== 1 ? 's' : ''})
              </span>
            )}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {filteredVideos.map((video) => (
              <div 
                key={video.id} 
                className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-all duration-200 cursor-pointer group"
                onClick={() => handleVideoClick(video.youtubeUrl)}
              >
                <div className="aspect-video bg-gradient-to-br from-green-100 to-blue-100 flex items-center justify-center relative">
                  <div className="text-4xl">{video.thumbnail}</div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-12 h-12 bg-white bg-opacity-90 rounded-full flex items-center justify-center group-hover:bg-opacity-100 group-hover:scale-110 transition-all duration-200">
                      <Play className="w-5 h-5 text-green-600 ml-1" />
                    </div>
                  </div>
                  <div className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded">
                    {video.duration}
                  </div>
                  <div className="absolute top-2 right-2">
                    <ExternalLink className="w-4 h-4 text-white bg-black bg-opacity-50 rounded p-0.5" />
                  </div>
                </div>
                <div className="p-4">
                  <h4 className="font-semibold text-gray-900 mb-2 group-hover:text-green-600 transition-colors">
                    {video.title}
                  </h4>
                  <div className="text-sm text-gray-500 mb-2">{video.views} views</div>
                  <p className="text-xs text-gray-600 line-clamp-2">{video.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Show message when no content matches filter */}
      {filteredArticles.length === 0 && filteredVideos.length === 0 && (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">🔍</div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No content found</h3>
          <p className="text-gray-600">Try adjusting your search or selecting a different category.</p>
        </div>
      )}

      {/* Quick Tips */}
      <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">Quick Tips for Today</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {tips.map((tip) => (
            <div key={tip.id} className="bg-white rounded-lg p-4 flex items-center space-x-4">
              <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                <BookOpen className="w-4 h-4 text-green-600" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-gray-900">{tip.title}</h4>
                <p className="text-sm text-gray-600">{tip.impact}</p>
              </div>
              <span className={`text-xs px-2 py-1 rounded-full ${
                tip.difficulty === 'Easy' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
              }`}>
                {tip.difficulty}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Article Modal */}
      {selectedArticle && selectedArticleData && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <div className="flex items-center space-x-3">
                <div className="text-2xl">
                  {selectedArticleData.image}
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">
                    {selectedArticleData.title}
                  </h3>
                  <div className="flex items-center space-x-4 text-sm text-gray-500 mt-1">
                    <span className="flex items-center space-x-1">
                      <User className="w-3 h-3" />
                      <span>{selectedArticleData.author}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <Clock className="w-3 h-3" />
                      <span>{selectedArticleData.readTime}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <Star className="w-3 h-3 text-yellow-500" />
                      <span>{selectedArticleData.rating}</span>
                    </span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => setSelectedArticle(null)}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
              <div 
                className="text-gray-700"
                dangerouslySetInnerHTML={{ 
                  __html: selectedArticleData.content
                }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Learn;